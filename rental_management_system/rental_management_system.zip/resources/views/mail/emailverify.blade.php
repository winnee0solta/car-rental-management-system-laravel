<h2>Welcome to Dai Call Rental Service.</h2>
<br>
<br>
<h4>
    <a href="{{env('APP_URL')}}/verify-email?id={{$user_id}}">Verify Email Address</a>
</h4>
<br>
