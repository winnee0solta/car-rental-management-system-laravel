<h2>Use given token to reset password.</h2>
<br>
<h4>
    Reset Token : {{$token}}
</h4>
<br>
