

<?php $__env->startSection('content'); ?>

<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal">
    Add Vehicle
</button>


<div class="row justify-content-center mt-3">
    <div class="col-md-12">
        <div class="card card-body table-responsive">
            <table class="table">
                <thead>
                    <tr>
                        <th>SN</th>
                        <th>Image</th>
                        <th>Name</th>
                        <th>Type</th>
                        <th>Hiring Cost</th>
                        <th>Status</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if(!empty($vehicle)): ?>
                    <?php $__currentLoopData = $vehicle; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td>
                            <?php echo e($loop->index + 1); ?>

                        </td>
                        <td>
                            <img src="<?php echo e(asset('/images/vehicles/'.$item['image'])); ?>" class="img-fluid"
                                style="height: 125px">
                        </td>
                        <td>
                            <?php echo e($item['name']); ?>

                        </td>
                        <td>
                            <?php echo e($item['type']); ?>

                        </td>
                        <td>
                            <?php echo e($item['hiring_cost']); ?>

                        </td>
                        <td>
                            <?php echo e($item['status']); ?>

                        </td>
                        <td>
                            <div class="d-flex">
                                <a href="/admin/vehicle/view/<?php echo e($item['id']); ?>" class="btn btn-success btn-sm">View</a>
                                <button type="button" class="btn btn-dark btn-sm ml-3" data-toggle="modal"
                                    data-target="#editModal-<?php echo e($item['id']); ?>">
                                    Edit
                                </button>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>



<?php $__env->stopSection(); ?>
<?php $__env->startSection('modal'); ?>
<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
    aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Add Vehicle</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form action="/admin/vehicle/add" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <label>Image</label>
                        <input name="image" required type="file" class="form-control" placeholder="Vehicle Picture">
                    </div>
                    <div class="form-group">
                        <label>Name</label>
                        <input name="name" requiredtype="text" class="form-control" placeholder="Enter Name">
                    </div>
                    <div class="form-group">
                        <label>Type</label>
                        <input name="type" required type="text" class="form-control" placeholder="Enter type">
                    </div>
                    <div class="form-group">
                        <label>Vehicle No</label>
                        <input name="no_plate" required type="text" class="form-control" placeholder="Enter Vehicle No">
                    </div>
                    <div class="form-group">
                        <label>No of seats</label>
                        <input name="no_of_seats" required type="number" class="form-control"
                            placeholder="Enter No of seats">
                    </div>
                    <div class="form-group">
                        <label>Condition</label>
                        <input name="condition" required type="text" class="form-control"
                            placeholder="Enter Vehicle Condition">
                    </div>
                    <div class="form-group">
                        <label>AC Condition</label>
                        <input name="ac_status" required type="text" class="form-control"
                            placeholder="Enter Vehicle AC Condition">
                    </div>
                    <div class="form-group">
                        <label>OWner Name</label>
                        <input name="owner_name" required type="text" class="form-control"
                            placeholder="Enter OWner Name">
                    </div>
                    <div class="form-group">
                        <label>Hiring Cost (RS)</label>
                        <input name="hiring_cost" required type="number" class="form-control"
                            placeholder="Enter Hiring Cost">
                    </div>
                    <div class="form-group">
                        <label>Status</label>
                        <select name="status" required class="form-control">
                            <option value="Available">Available</option>
                            <option value="Unavailable">Unavailable</option>
                        </select>

                    </div>
                    <button type="submit" class="btn btn-success">ADD</button>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>


<?php if(!empty($vehicle)): ?>
<?php $__currentLoopData = $vehicle; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="modal fade" id="editModal-<?php echo e($item['id']); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
    aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Edit Vehicle</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form action="/admin/vehicle/edit/<?php echo e($item['id']); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <label>Image</label>
                        <input name="image" type="file" class="form-control" placeholder="Vehicle Picture">
                    </div>
                    <div class="form-group">
                        <label>Name</label>
                        <input name="name" requiredtype="text" class="form-control" placeholder="Enter Name"
                            value="<?php echo e($item['name']); ?>">
                    </div>
                    <div class="form-group">
                        <label>Type</label>
                        <input name="type" required type="text" class="form-control" placeholder="Enter type"
                            value="<?php echo e($item['type']); ?>">
                    </div>
                    <div class="form-group">
                        <label>Vehicle No</label>
                        <input name="no_plate" required type="text" class="form-control" placeholder="Enter Vehicle No"
                            value="<?php echo e($item['no_plate']); ?>">
                    </div>
                    <div class="form-group">
                        <label>No of seats</label>
                        <input name="no_of_seats" required type="number" class="form-control"
                            placeholder="Enter No of seats" value="<?php echo e($item['no_of_seats']); ?>">
                    </div>
                    <div class="form-group">
                        <label>Condition</label>
                        <input name="condition" required type="text" class="form-control"
                            placeholder="Enter Vehicle Condition" value="<?php echo e($item['condition']); ?>">
                    </div>
                    <div class="form-group">
                        <label>AC Condition</label>
                        <input name="ac_status" required type="text" class="form-control"
                            placeholder="Enter Vehicle AC Condition" value="<?php echo e($item['ac_status']); ?>">
                    </div>
                    <div class="form-group">
                        <label>OWner Name</label>
                        <input name="owner_name" required type="text" class="form-control"
                            placeholder="Enter OWner Name" value="<?php echo e($item['owner_name']); ?>">
                    </div>
                    <div class="form-group">
                        <label>Hiring Cost (RS)</label>
                        <input name="hiring_cost" required type="number" class="form-control"
                            placeholder="Enter Hiring Cost" value="<?php echo e($item['hiring_cost']); ?>">
                    </div>
                    <div class="form-group">
                        <label>Status</label>
                        <select name="status" required class="form-control">
                            <?php if($item['status'] == 'Available'): ?>
                            <option value="Available" selected>Available</option>
                            <?php else: ?>
                            <option value="Available">Available</option>

                            <?php endif; ?>
                            <?php if($item['status'] == 'Unavailable'): ?>
                            <option value="Unavailable" selected>Unavailable</option>
                            <?php else: ?>
                            <option value="Unavailable">Unavailable</option>

                            <?php endif; ?>
                        </select>

                    </div>
                    <button type="submit" class="btn btn-success">Edit</button>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\WTN\islinton\rental_management_system\rental_management_system\resources\views/admin/vehicle/index.blade.php ENDPATH**/ ?>