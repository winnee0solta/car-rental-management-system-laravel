

<?php $__env->startSection('content'); ?>

<a href="/booking/new" type="button" class="btn btn-dark">
    New Booking
</a>

<h4 class="h4 mt-5">My Bookings</h4>


<div class="row">
    <?php if(!empty($bookings)): ?>
    <?php $__currentLoopData = $bookings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $booking): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="col-12 col-md-4 mt-2">
        <div class="card">
            <div class="card-body">
                <table class="table">
                    <tr>
                        <td>Booking For</td>
                        <td><?php echo e($booking['name']); ?></td>
                    </tr>
                    <tr>
                        <td>Contact No</td>
                        <td><?php echo e($booking['phone']); ?></td>
                    </tr>
                    <tr>
                        <td>Travel Date (from)</td>
                        <td><?php echo e($booking['travel_date_from']); ?></td>
                    </tr>
                    <tr>
                        <td>Travel Date (to)</td>
                        <td><?php echo e($booking['travel_date_to']); ?></td>
                    </tr>
                    <tr>
                        <td>Vehicle</td>
                        <td>
                            <a href="/vehicle/<?php echo e($booking['vehicle_id']); ?>" target="_blank" class="text-info">View</a>
                        </td>
                    </tr>
                    <tr>
                        <td>Driver Name</td>
                        <td><?php echo e($booking['driver_data']['name']); ?></td>
                    </tr>
                    <tr>
                        <td>Driver Phone</td>
                        <td><?php echo e($booking['driver_data']['phone']); ?></td>
                    </tr> 
                    <tr>
                        <td>Payment Status</td>
                        <td>
                            <?php if($booking['payement_completed']): ?>
                            <span class="badge badge-pill badge-success py-1 px-3">Payment Completed</span>
                           
                            <?php else: ?> 
                            <span class="badge badge-pill badge-danger py-1 px-3">Payment Remaning</span>
                            
                            <?php endif; ?>
                        </td>
                    </tr>
                    <tr>
                        <td>Note</td>
                        <td><?php echo e($booking['note']); ?></td>
                    </tr>
 
                    
                </table>
            </div>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>

</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('site.layout.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\WTN\islinton\rental_management_system\rental_management_system\resources\views/site/booking.blade.php ENDPATH**/ ?>