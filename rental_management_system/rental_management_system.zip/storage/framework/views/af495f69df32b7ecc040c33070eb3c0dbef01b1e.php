

<?php $__env->startSection('content'); ?>




<div class="row justify-content-center">

    <div class="col-12 mt-2">
        <div class="card">
            <div class="card-body table-responsive">
                <table class="table">
                    <thead>
                        <tr>
                            <th>SN</th>
                            <th>Name</th>
                            <th>Phone</th>
                            <th>Email</th>
                            <th>Verified</th>
                            <th>Registeted at</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if(!empty($users)): ?>
                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($loop->index + 1); ?></td>
                            <td><?php echo e($item->name); ?></td>
                            <td><?php echo e($item->phone); ?></td> 
                            <td><?php echo e($item->email); ?></td>   
                            <td>
                                <?php if($item->email_verified): ?>
                                    Email Verified
                                <?php else: ?> 
                                Email Not Verified
                                <?php endif; ?>
                                </td> 
                                <td><?php echo e($item->created_at); ?></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </tbody>


                    
                </table>
            </div>
        </div>
    </div>


</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\WTN\islinton\rental_management_system\rental_management_system\resources\views/admin/client/index.blade.php ENDPATH**/ ?>