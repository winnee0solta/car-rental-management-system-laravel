

<?php $__env->startSection('content'); ?>

<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#addModal">
    Add Driver
</button>


<div class="row justify-content-center mt-3">
    <div class="col-md-12">
        <div class="card card-body table-responsive">
            <table class="table">
                <thead>
                    <tr>
                        <th>SN</th>
                        <th>Image</th>
                        <th>Name</th>
                        <th>address</th>
                        <th>Citizenship No</th>
                        <th>Experience</th>
                        <th>License</th>
                        <th>Status</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if(!empty($driver)): ?>
                    <?php $__currentLoopData = $driver; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td>
                            <?php echo e($loop->index + 1); ?>

                        </td>
                        <td>
                            <img src="<?php echo e(asset('/images/drivers/'.$item['image'])); ?>" class="img-fluid"
                                style="height: 125px">
                        </td>
                        <td>
                            <?php echo e($item['name']); ?>

                        </td>
                        <td>
                            <?php echo e($item['address']); ?>

                        </td>
                        <td>
                            <?php echo e($item['citizenship_no']); ?>

                        </td>
                        <td>
                            <?php echo e($item['experience']); ?>

                        </td>
                        <td>
                            <img src="<?php echo e(asset('/images/drivers/'.$item['license'])); ?>" class="img-fluid"
                                style="height: 125px">
                        </td>
                        <td>
                            <?php echo e($item['status']); ?>

                        </td>
                        <td>
                            <div class="d-flex">
                                <button type="button" class="btn btn-dark btn-sm" data-toggle="modal"
                                    data-target="#editModal-<?php echo e($item['id']); ?>">
                                    Edit
                                </button>

                                <a href="/admin/driver/delete/<?php echo e($item['id']); ?>"
                                    class="btn btn-danger btn-sm ml-3">Delete</a>

                            </div>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>



<?php $__env->stopSection(); ?>
<?php $__env->startSection('modal'); ?>
<!-- Modal -->
<div class="modal fade" id="addModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
    aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Add Driver</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form action="/admin/driver/add" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <label>Driver Picture</label>
                        <input name="image" required type="file" class="form-control">
                    </div>
                    <div class="form-group">
                        <label>Name</label>
                        <input name="name" required type="text" class="form-control" placeholder="Enter Name">
                    </div>
                    <div class="form-group">
                        <label>Address</label>
                        <input name="address" required type="text" class="form-control" placeholder="Enter address">
                    </div>
                    <div class="form-group">
                        <label>Citizenship No</label>
                        <input name="citizenship_no" required type="text" class="form-control"
                            placeholder="Enter Citizenship No">
                    </div>
                    <div class="form-group">
                        <label>Experiences</label>
                        <input name="experience" required type="text" class="form-control"
                            placeholder="Enter Experience">
                    </div>
                    <div class="form-group">
                        <label>License Picture</label>
                        <input name="license" required type="file" class="form-control">
                    </div>
                    <div class="form-group">
                        <label>Status</label>
                        <select name="status" required class="form-control">
                            <option value="Available">Available</option>
                            <option value="Unavailable">Unavailable</option>
                        </select>

                    </div>
                    <button type="submit" class="btn btn-success">ADD</button>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>


<?php if(!empty($driver)): ?>
<?php $__currentLoopData = $driver; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="modal fade" id="editModal-<?php echo e($item['id']); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
    aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Edit Driver Detail</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form action="/admin/driver/edit/<?php echo e($item['id']); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>

                    <div class="form-group">
                        <label>Driver Picture</label>
                        <input name="image" type="file" class="form-control">
                    </div>
                    <div class="form-group">
                        <label>Name</label>
                        <input name="name" required type="text" class="form-control" placeholder="Enter Name"
                            value="<?php echo e($item['name']); ?>">
                    </div>
                    <div class="form-group">
                        <label>Address</label>
                        <input name="address" required type="text" class="form-control" placeholder="Enter address"
                            value="<?php echo e($item['address']); ?>">
                    </div>
                    <div class="form-group">
                        <label>Citizenship No</label>
                        <input name="citizenship_no" required type="text" class="form-control"
                            placeholder="Enter Citizenship No" value="<?php echo e($item['citizenship_no']); ?>">
                    </div>
                    <div class="form-group">
                        <label>Experiences</label>
                        <input name="experience" required type="text" class="form-control"
                            placeholder="Enter Experience" value="<?php echo e($item['experience']); ?>">
                    </div>

                    <div class="form-group">
                        <label>License Picture</label>
                        <input name="license" type="file" class="form-control">
                    </div>

                    <div class="form-group">
                        <label>Status</label>
                        <select name="status" required class="form-control">
                            <?php if($item['status'] == 'Available'): ?>
                            <option value="Available" selected>Available</option>
                            <?php else: ?>
                            <option value="Available">Available</option>

                            <?php endif; ?>
                            <?php if($item['status'] == 'Unavailable'): ?>
                            <option value="Unavailable" selected>Unavailable</option>
                            <?php else: ?>
                            <option value="Unavailable">Unavailable</option>

                            <?php endif; ?>
                        </select>

                    </div>
                    <button type="submit" class="btn btn-success">Edit</button>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\WTN\islinton\rental_management_system\rental_management_system\resources\views/admin/driver/index.blade.php ENDPATH**/ ?>