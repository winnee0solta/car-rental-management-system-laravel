

<?php $__env->startSection('content'); ?>

<div class="row justify-content-center mt-4">
    <div class="col-12 col-md-4">
         <p class="h3">
            Verify you email to complete registration.
         </p>
    </div> 
</div>
 
 

<?php $__env->stopSection(); ?>
<?php echo $__env->make('site.layout.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\WTN\islinton\rental_management_system\rental_management_system\resources\views/site/verifyemail.blade.php ENDPATH**/ ?>