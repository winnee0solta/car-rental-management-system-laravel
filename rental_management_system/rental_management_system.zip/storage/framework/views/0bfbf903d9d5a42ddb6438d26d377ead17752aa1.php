

<?php $__env->startSection('content'); ?>
 
<div class="row">
    <?php if(!empty($vehicles)): ?>
    <?php $__currentLoopData = $vehicles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vehicle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="col-12 col-md-4">
        <div class="card">
            <div class="card-body">
                <img src="<?php echo e(asset('/images/vehicles/'.$vehicle['image'])); ?>" class="img-fluid d-block m-auto"
                    style="height: 200px">
                <table class="table">
                    <tr>
                        <td>Name</td>
                        <td><?php echo e($vehicle['name']); ?></td>
                    </tr>
                    <tr>
                        <td>Type</td>
                        <td><?php echo e($vehicle['type']); ?></td>
                    </tr>
                    <tr>
                        <td>No Of Seats</td>
                        <td><?php echo e($vehicle['no_of_seats']); ?></td>
                    </tr>
                    <tr>
                        <td>Status</td>
                        <td>
                            <?php if($vehicle->status == 'Available' ): ?>
                            <span class="badge badge-pill badge-success py-1 px-3">Available</span>
                            <?php endif; ?>
                            <?php if($vehicle->status == 'Unavailable' ): ?>
                            <span class="badge badge-pill badge-danger py-1 px-3">Unavailable</span>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <tr>
                        <td colspan="2" class="text-center">
                            <a href="/vehicle/<?php echo e($vehicle['id']); ?>" class="btn btn-info">More Information</a>
                        </td>
                    </tr>
                </table>
            </div>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>

</div>
 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('site.layout.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\WTN\islinton\rental_management_system\rental_management_system\resources\views/site/vehicle.blade.php ENDPATH**/ ?>