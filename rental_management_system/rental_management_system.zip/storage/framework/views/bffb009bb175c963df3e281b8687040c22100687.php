

<?php $__env->startSection('content'); ?>

<nav aria-label="breadcrumb">
    <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="/booking">Booking Home</a></li>
        <li class="breadcrumb-item active" aria-current="page"><?php echo e($vehicle->name); ?></li>
        <li class="breadcrumb-item active" aria-current="page">Select Driver</li>
    </ol>
</nav>



<div class="row">
    <?php if(!empty($drivers)): ?>
    <?php $__currentLoopData = $drivers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $driver): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="col-12 col-md-4">
        <div class="card">
            <div class="card-body">
                <img src="<?php echo e(asset('/images/drivers/'.$driver->image)); ?>" class="img-fluid d-block m-auto"
                    style="height: 200px">
                <table class="table">
                    <tr>
                        <td>Name</td>
                        <td><?php echo e($driver['name']); ?></td>
                    </tr>
                    <tr>
                        <td>Address</td>
                        <td><?php echo e($driver['address']); ?></td>
                    </tr>
                    <tr>
                        <td>Citizenship No</td>
                        <td><?php echo e($driver['citizenship_no']); ?></td>
                    </tr>
                    <tr>
                        <td>Experience No</td>
                        <td><?php echo e($driver['experience']); ?></td>
                    </tr>
                    <tr>
                        <td>Driving License</td>
                        <td><img src="<?php echo e(asset('/images/drivers/'.$driver->license)); ?>" class="img-fluid"
                                style="height: 125px"></td>
                    </tr>
                    <tr>
                        <td>Status</td>
                        <td>
                            <?php if($driver->status == 'Available' ): ?>
                            <span class="badge badge-pill badge-success py-1 px-3">Available</span>
                            <?php endif; ?>
                            <?php if($driver->status == 'Unavailable' ): ?>
                            <span class="badge badge-pill badge-danger py-1 px-3">Unavailable</span>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <tr>
                        <td colspan="2" class="text-center"> 
                            <a href="/booking/new/vehicle/<?php echo e($vehicle['id']); ?>/driver/<?php echo e($driver->id); ?>" class="btn btn-dark">Select Driver </a>
                        </td>
                    </tr>
                </table>
            </div>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>

</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('site.layout.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\WTN\islinton\rental_management_system\rental_management_system\resources\views/site/booking-two.blade.php ENDPATH**/ ?>