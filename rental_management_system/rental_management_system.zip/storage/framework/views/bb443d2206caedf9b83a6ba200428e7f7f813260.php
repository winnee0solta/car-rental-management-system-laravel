

<?php $__env->startSection('content'); ?>


<nav aria-label="breadcrumb">
    <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="/admin/vehicle">Vehicles</a></li>
        <li class="breadcrumb-item active" aria-current="page"><?php echo e($vehicle['name']); ?></li>
    </ol>
</nav>

<div class="row justify-content-center mt-3">
    <div class="col-md-8">
        <div class="card card-body">

            <img src="<?php echo e(asset('/images/vehicles/'.$vehicle['image'])); ?>" class="img-fluid d-block m-auto"
                style="height: 225px">

            <table class="table">
                <tr>
                    <td>Name</td>
                    <td><?php echo e($vehicle['name']); ?></td>
                </tr>
                <tr>
                    <td>Type</td>
                    <td><?php echo e($vehicle['type']); ?></td>
                </tr>
                <tr>
                    <td>No Plate</td>
                    <td><?php echo e($vehicle['no_plate']); ?></td>
                </tr>
                <tr>
                    <td>No Of Seats</td>
                    <td><?php echo e($vehicle['no_of_seats']); ?></td>
                </tr>
                <tr>
                    <td>Condition</td>
                    <td><?php echo e($vehicle['condition']); ?></td>
                </tr>
                <tr>
                    <td>Ac Status</td>
                    <td><?php echo e($vehicle['ac_status']); ?></td>
                </tr>
                <tr>
                    <td>Owner Name</td>
                    <td><?php echo e($vehicle['owner_name']); ?></td>
                </tr>
                <tr>
                    <td>Hiring Cost</td>
                    <td>Rs <?php echo e($vehicle['hiring_cost']); ?></td>
                </tr>
                <tr>
                    <td>Status</td>
                    <td><?php echo e($vehicle['status']); ?></td>
                </tr>
            </table>

        </div>
    </div>
</div>
<div class="row justify-content-center mt-3">
    <div class="col-md-12">
        <div class="card card-body">
            <div class="d-flex">
                <h3 class="mr-4">Drivers</h3>
                <button type="button" class="btn btn-primary btn-sm" data-toggle="modal" data-target="#addModal">
                    Add Driver
                </button>
            </div>
            <table class="table">
                <thead>
                    <tr>
                        <th>SN</th>
                        <th>Image</th>
                        <th>Name</th>
                        <th>address</th>
                        <th>Citizenship No</th>
                        <th>Experience</th>
                        <th>License</th>
                        <th>Status</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if(!empty($drivers)): ?>
                    <?php $__currentLoopData = $drivers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td>
                            <?php echo e($loop->index + 1); ?>

                        </td>
                        <td>
                            <img src="<?php echo e(asset('/images/drivers/'.$item->image)); ?>" class="img-fluid"
                                style="height: 125px">
                        </td>
                        <td>
                            <?php echo e($item->name); ?>

                        </td>
                        <td>
                            <?php echo e($item->address); ?>

                        </td>
                        <td>
                            <?php echo e($item->citizenship_no); ?>

                        </td>
                        <td>
                            <?php echo e($item->experience); ?>

                        </td>
                        <td>
                            <img src="<?php echo e(asset('/images/drivers/'.$item->license)); ?>" class="img-fluid"
                                style="height: 125px">
                        </td>
                        <td>
                            <?php echo e($item->status); ?>

                        </td>
                        <td>
                            <div class="d-flex">
                                <a href="/admin/vehicle/<?php echo e($vehicle['id']); ?>/remove-driver/<?php echo e($item->id); ?>"
                                    class="btn btn-danger btn-sm ml-3">Remove</a>

                            </div>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </tbody>
            </table>

        </div>
    </div>
</div>

<div>
    <a href="/admin/vehicle/delete/<?php echo e($vehicle['id']); ?>" class="btn btn-danger mt-5"> Delete Vehicle</a>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('modal'); ?>

<div class="modal fade" id="addModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
    aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Add Driver</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">

                <div class=" table-responsive">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>SN</th>
                                <th>Image</th>
                                <th>Name</th>
                                <th>address</th>
                                <th>Citizenship No</th>
                                <th>Experience</th>
                                <th>License</th>
                                <th>Status</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if(!empty($alldrivers)): ?>
                            <?php $__currentLoopData = $alldrivers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>
                                    <?php echo e($loop->index + 1); ?>

                                </td>
                                <td>
                                    <img src="<?php echo e(asset('/images/drivers/'.$item['image'])); ?>" class="img-fluid">
                                </td>
                                <td>
                                    <?php echo e($item['name']); ?>

                                </td>
                                <td>
                                    <?php echo e($item['address']); ?>

                                </td>
                                <td>
                                    <?php echo e($item['citizenship_no']); ?>

                                </td>
                                <td>
                                    <?php echo e($item['experience']); ?>

                                </td>
                                <td>
                                    <img src="<?php echo e(asset('/images/drivers/'.$item['license'])); ?>" class="img-fluid">
                                </td>
                                <td>
                                    <?php echo e($item['status']); ?>

                                </td>
                                <td>
                                    <a href="/admin/vehicle/<?php echo e($vehicle['id']); ?>/add-driver/<?php echo e($item['id']); ?>"
                                        class="btn btn-danger btn-sm ml-3">Add Driver</a>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>

            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\WTN\islinton\rental_management_system\rental_management_system\resources\views/admin/vehicle/view.blade.php ENDPATH**/ ?>