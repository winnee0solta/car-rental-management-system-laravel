<h2>Welcome to Online Job Portal.</h2>
<br>
<br>
<h4>
    <a href="<?php echo e(env('APP_URL')); ?>/verify-email?id=<?php echo e($user_id); ?>">Verify Email Address</a>
</h4>
<br>
<?php /**PATH F:\WTN\islinton\rental_management_system\rental_management_system\resources\views/mail/emailverify.blade.php ENDPATH**/ ?>