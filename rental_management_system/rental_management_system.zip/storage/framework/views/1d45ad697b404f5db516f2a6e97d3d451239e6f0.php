

<?php $__env->startSection('content'); ?>
<nav aria-label="breadcrumb">
    <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="/vehicle">Vehicles</a></li>
        <li class="breadcrumb-item active" aria-current="page"><?php echo e($vehicle['name']); ?></li>
    </ol>
</nav>

<div class="row justify-content-center mt-3">
    <div class="col-md-8">
        <div class="card card-body">

            <img src="<?php echo e(asset('/images/vehicles/'.$vehicle['image'])); ?>" class="img-fluid d-block m-auto"
                style="height: 225px">

            <table class="table">
                <tr>
                    <td>Name</td>
                    <td><?php echo e($vehicle['name']); ?></td>
                </tr>
                <tr>
                    <td>Type</td>
                    <td><?php echo e($vehicle['type']); ?></td>
                </tr>
                <tr>
                    <td>No Plate</td>
                    <td><?php echo e($vehicle['no_plate']); ?></td>
                </tr>
                <tr>
                    <td>No Of Seats</td>
                    <td><?php echo e($vehicle['no_of_seats']); ?></td>
                </tr>
                <tr>
                    <td>Condition</td>
                    <td><?php echo e($vehicle['condition']); ?></td>
                </tr>
                <tr>
                    <td>Ac Status</td>
                    <td><?php echo e($vehicle['ac_status']); ?></td>
                </tr>
                <tr>
                    <td>Owner Name</td>
                    <td><?php echo e($vehicle['owner_name']); ?></td>
                </tr>
                <tr>
                    <td>Hiring Cost</td>
                    <td>Rs <?php echo e($vehicle['hiring_cost']); ?></td>
                </tr>
                <tr>
                    <td>Status</td>
                    <td>
                        <?php if($vehicle->status == 'Available' ): ?>
                        <span class="badge badge-pill badge-success py-1 px-3">Available</span>
                        <?php endif; ?>
                        <?php if($vehicle->status == 'Unavailable' ): ?>
                        <span class="badge badge-pill badge-danger py-1 px-3">Unavailable</span>
                        <?php endif; ?> 
                    </td>
                </tr>
            </table>

        </div>
    </div>
</div>

<div class="row justify-content-center mt-3 px-0">
    <div class="col-12 px-0">
        <div class="card card-body">
            <div class="d-flex">
                <h3 class="mr-4">Drivers</h3> 
            </div>
            <table class="table">
                <thead>
                    <tr>
                        <th>SN</th>
                        <th>Image</th>
                        <th>Name</th>
                        <th>address</th>
                        <th>Citizenship No</th>
                        <th>Experience</th>
                        <th>License</th>
                        <th>Status</th> 
                    </tr>
                </thead>
                <tbody>
                    <?php if(!empty($drivers)): ?>
                    <?php $__currentLoopData = $drivers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td>
                            <?php echo e($loop->index + 1); ?>

                        </td>
                        <td>
                            <img src="<?php echo e(asset('/images/drivers/'.$item->image)); ?>" class="img-fluid"
                                style="height: 100px">
                        </td>
                        <td>
                            <?php echo e($item->name); ?>

                        </td>
                        <td>
                            <?php echo e($item->address); ?>

                        </td>
                        <td>
                            <?php echo e($item->citizenship_no); ?>

                        </td>
                        <td>
                            <?php echo e($item->experience); ?>

                        </td>
                        <td>
                            <img src="<?php echo e(asset('/images/drivers/'.$item->license)); ?>" class="img-fluid"
                                style="height: 125px">
                        </td>
                        <td>
                            <?php if($item->status == 'Available' ): ?>
                                <span class="badge badge-pill badge-success py-1 px-3">Available</span> 
                            <?php endif; ?>
                            <?php if($item->status == 'Unavailable' ): ?>
                                <span class="badge badge-pill badge-danger py-1 px-3">Unavailable</span> 
                            <?php endif; ?> 
                        </td> 
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </tbody>
            </table>

        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('site.layout.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\WTN\islinton\rental_management_system\rental_management_system\resources\views/site/single-vehicle.blade.php ENDPATH**/ ?>