

<?php $__env->startSection('content'); ?>
<nav aria-label="breadcrumb">
    <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="/">Home</a></li>
        <li class="breadcrumb-item active" aria-current="page">Feedbacks</li>
    </ol>
</nav>

<?php if(Auth::check()): ?>
   <button type="button" class="btn btn-success" data-toggle="modal" data-target="#exampleModal">
    Write Feedback
</button> 
<?php endif; ?>

<div class="row">
    <?php if(!empty($feedbacks)): ?>
    <?php $__currentLoopData = $feedbacks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $feedback): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="col-12 col-md-4 mt-3">
        <div class="card bg-info text-white">
            <div class="card-body">
                <div class="h4">
                    <?php echo e($feedback->subject); ?>

                </div>
             
                <div>
                    <?php echo e($feedback->message); ?>

                </div>
                <div class="mt-3">
                    <?php echo e($feedback->name); ?>

                </div>
                <div>
                    <?php echo e($feedback->email); ?>

                </div>

              
            </div>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>

</div>


<?php $__env->stopSection(); ?>


<?php $__env->startSection('modal'); ?>
<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
    aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Add Vehicle</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form action="/feedback/add" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?> 
                    <div class="form-group">
                        <label>Name</label>
                        <input name="name" required type="text" class="form-control" placeholder="Enter Name">
                    </div>
                    <div class="form-group">
                        <label>Email</label>
                        <input name="email" required type="email" class="form-control" placeholder="Enter Email">
                    </div>
                    <div class="form-group">
                        <label>Subject</label>
                        <input name="subject" required type="text" class="form-control" placeholder="Enter subject">
                    </div>
                    <div class="form-group">
                        <label>Message</label>
                        <textarea name="message" required type="text" class="form-control" ></textarea>
                    </div>
                     
                    <button type="submit" class="btn btn-success">ADD</button>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>


 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('site.layout.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\WTN\islinton\rental_management_system\rental_management_system\resources\views/site/feedback.blade.php ENDPATH**/ ?>