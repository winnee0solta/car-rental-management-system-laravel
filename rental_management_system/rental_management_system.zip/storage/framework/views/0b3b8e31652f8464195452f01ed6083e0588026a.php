

<?php $__env->startSection('content'); ?>

 




<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\WTN\islinton\rental_management_system\rental_management_system\resources\views/admin/home.blade.php ENDPATH**/ ?>